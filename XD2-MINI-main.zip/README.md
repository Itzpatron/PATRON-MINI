# [D E P L O Y](https://dashboard.heroku.com/new?template=https://github.com/1122bot/XD2-MINI)
bot mini
