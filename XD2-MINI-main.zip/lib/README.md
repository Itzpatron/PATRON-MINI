mini bot
